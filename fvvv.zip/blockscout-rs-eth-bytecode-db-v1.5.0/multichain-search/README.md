# <h1 align="center"> Blockscout multichain search </h1>

This service provides web application for blockscout multi-chain-search.

Basically, it aggregates responses from all blockscout instances, and combines them into convenient form.

Backend is written in rust

Frontend is written in react and nextjs
