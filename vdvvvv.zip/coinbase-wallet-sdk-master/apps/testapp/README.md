# testapp

This is a demo app for development purposes. The `yarn dev` command will start two dev servers in parallel:
    wallet-sdk-development
    @coinbase/wallet-sdk
