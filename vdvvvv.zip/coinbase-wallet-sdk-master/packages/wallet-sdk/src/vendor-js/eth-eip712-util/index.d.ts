const module: {
  hashForSignTypedDataLegacy: (params: { data: any }) => Buffer;
  hashForSignTypedData_v3: (params: { data: any }) => Buffer;
  hashForSignTypedData_v4: (params: { data: any }) => Buffer;
  TypedDataUtils: {
    sanitizeData: (data: any) => any;
    hashStruct: (primaryType: string, data: any, types: any, useV4: any) => Buffer;
  };
};

export = module;
