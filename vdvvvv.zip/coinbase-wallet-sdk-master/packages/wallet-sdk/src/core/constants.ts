export const LINK_API_URL = 'https://www.walletlink.org';
